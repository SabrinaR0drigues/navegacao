import React from "react";
import { View, Text, Button } from "react-native";

export default function DetalhesScreen({ navigation }){
    return(
        <View>
            <Text>Tela Detalhes</Text>

            <Button 
                title="Voltar" 
                onPress={()=>{navigation.navigate.goBack()}}
            >
            </Button>

        </View>
    )
}


